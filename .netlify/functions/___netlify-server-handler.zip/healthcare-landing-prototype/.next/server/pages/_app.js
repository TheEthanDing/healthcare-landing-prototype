var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__4b169cc5._.js")
R.m(93532)
module.exports=R.m(93532).exports
