var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__d3cc52de._.js")
R.c("server/chunks/ssr/[root-of-the-server]__c0bd8c72._.js")
R.m(85385)
module.exports=R.m(85385).exports
