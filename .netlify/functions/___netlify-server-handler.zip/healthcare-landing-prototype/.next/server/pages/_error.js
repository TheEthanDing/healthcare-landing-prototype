var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/[root-of-the-server]__d3cc52de._.js")
R.c("server/chunks/ssr/[root-of-the-server]__c0bd8c72._.js")
R.c("server/chunks/ssr/59cc3_next_298535ac._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/59cc3_9df4abb2._.js")
R.m(35980)
module.exports=R.m(35980).exports
