module.exports=[43417,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},34379,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(43417).default,width:256,height:256}}];

//# sourceMappingURL=healthcare-landing-prototype_app_439eff9c._.js.map