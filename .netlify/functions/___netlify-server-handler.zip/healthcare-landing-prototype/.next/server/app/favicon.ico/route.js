var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__c614bf27._.js")
R.c("server/chunks/59cc3_next_dist_bfbc1c35._.js")
R.c("server/chunks/[root-of-the-server]__eb59d062._.js")
R.c("server/chunks/59cc3_next_dist_832e08c0._.js")
R.m(27658)
R.m(46976)
module.exports=R.m(46976).exports
